g++ ../utils.h
g++ AES.h
g++ test2.cpp -o test2