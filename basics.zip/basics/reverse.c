#include "gmp.h"
#include <stdio.h>
void reverseSentence();
int main() {
    printf("Enter a sentence: ");
    reverseSentence();
    return 0;
}

void reverseSentence() {
    //char c;
    mpz_t c;
    mpz_init(c);
    //scanf("%c", &c);
    gmp_scanf("%Zd",c);
    //if (c != '\n') {
    if (mpz_cmp_ui(c,0)!='\n'){
        reverseSentence();
        gmp_printf("%Zd", c);
    }
}
