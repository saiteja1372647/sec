rc4
===

A Python implementation of the RC4 encryption algorithm
